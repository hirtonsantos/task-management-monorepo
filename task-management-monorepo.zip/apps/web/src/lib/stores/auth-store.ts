import { create } from "zustand"
import { persist } from "zustand/middleware"
import { authService } from "../api/auth.service"

interface User {
  id: string
  name: string
  email: string
  role: string
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  setUser: (user: User | null) => void
  checkAuth: () => Promise<void>
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: true,

      login: async (email, password) => {
        const { data } = await authService.login({ email, password })
        localStorage.setItem("accessToken", data.data.accessToken)
        localStorage.setItem("refreshToken", data.data.refreshToken)
        set({ user: data.data.user, isAuthenticated: true })
      },

      register: async (name, email, password) => {
        const { data } = await authService.register({ name, email, password })
        localStorage.setItem("accessToken", data.data.accessToken)
        localStorage.setItem("refreshToken", data.data.refreshToken)
        set({ user: data.data.user, isAuthenticated: true })
      },

      logout: async () => {
        try {
          await authService.logout()
        } finally {
          localStorage.removeItem("accessToken")
          localStorage.removeItem("refreshToken")
          set({ user: null, isAuthenticated: false })
        }
      },

      setUser: (user) => set({ user, isAuthenticated: !!user }),

      checkAuth: async () => {
        try {
          const token = localStorage.getItem("accessToken")
          if (!token) {
            set({ isLoading: false, isAuthenticated: false })
            return
          }
          const { data } = await authService.me()
          set({ user: data.data, isAuthenticated: true, isLoading: false })
        } catch {
          localStorage.removeItem("accessToken")
          localStorage.removeItem("refreshToken")
          set({ user: null, isAuthenticated: false, isLoading: false })
        }
      },
    }),
    {
      name: "auth-storage",
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    },
  ),
)
