/* eslint-disable */
import { Test, describe, beforeAll, afterAll, it, expect, type TestingModule } from "@jest/globals"
import { type INestApplication, ValidationPipe } from "@nestjs/common"
import * as request from "supertest"
import { AppModule } from "../src/app.module"

describe("Auth (e2e)", () => {
  let app: INestApplication
  let accessToken: string
  let refreshToken: string

  const testUser = {
    name: "Auth Test User",
    email: `authtest-${Date.now()}@example.com`,
    password: "Test@123",
  }

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile()

    app = moduleFixture.createNestApplication()
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    )
    app.setGlobalPrefix("api/v1")
    await app.init()
  })

  afterAll(async () => {
    await app.close()
  })

  describe("POST /api/v1/auth/register", () => {
    it("should register a new user", async () => {
      const response = await request(app.getHttpServer()).post("/api/v1/auth/register").send(testUser).expect(201)

      expect(response.body.success).toBe(true)
      expect(response.body.data.user.email).toBe(testUser.email)
      expect(response.body.data.user.name).toBe(testUser.name)
      expect(response.body.data.user.password).toBeUndefined()
      expect(response.body.data.accessToken).toBeDefined()
      expect(response.body.data.refreshToken).toBeDefined()
    })

    it("should fail with duplicate email", async () => {
      await request(app.getHttpServer()).post("/api/v1/auth/register").send(testUser).expect(409)
    })

    it("should fail with weak password", async () => {
      const weakPasswordUser = {
        name: "Weak Password User",
        email: "weak@example.com",
        password: "123",
      }

      await request(app.getHttpServer()).post("/api/v1/auth/register").send(weakPasswordUser).expect(400)
    })

    it("should fail with invalid email", async () => {
      const invalidEmailUser = {
        name: "Invalid Email User",
        email: "not-an-email",
        password: "Test@123",
      }

      await request(app.getHttpServer()).post("/api/v1/auth/register").send(invalidEmailUser).expect(400)
    })
  })

  describe("POST /api/v1/auth/login", () => {
    it("should login successfully", async () => {
      const response = await request(app.getHttpServer())
        .post("/api/v1/auth/login")
        .send({
          email: testUser.email,
          password: testUser.password,
        })
        .expect(200)

      expect(response.body.success).toBe(true)
      expect(response.body.data.accessToken).toBeDefined()
      expect(response.body.data.refreshToken).toBeDefined()

      accessToken = response.body.data.accessToken
      refreshToken = response.body.data.refreshToken
    })

    it("should fail with wrong password", async () => {
      await request(app.getHttpServer())
        .post("/api/v1/auth/login")
        .send({
          email: testUser.email,
          password: "WrongPassword123",
        })
        .expect(401)
    })

    it("should fail with non-existent user", async () => {
      await request(app.getHttpServer())
        .post("/api/v1/auth/login")
        .send({
          email: "nonexistent@example.com",
          password: "Test@123",
        })
        .expect(401)
    })
  })

  describe("GET /api/v1/auth/me", () => {
    it("should return current user profile", async () => {
      const response = await request(app.getHttpServer())
        .get("/api/v1/auth/me")
        .set("Authorization", `Bearer ${accessToken}`)
        .expect(200)

      expect(response.body.success).toBe(true)
      expect(response.body.data.email).toBe(testUser.email)
      expect(response.body.data.password).toBeUndefined()
    })

    it("should fail without token", async () => {
      await request(app.getHttpServer()).get("/api/v1/auth/me").expect(401)
    })

    it("should fail with invalid token", async () => {
      await request(app.getHttpServer()).get("/api/v1/auth/me").set("Authorization", "Bearer invalid-token").expect(401)
    })
  })

  describe("POST /api/v1/auth/refresh", () => {
    it("should refresh tokens", async () => {
      const response = await request(app.getHttpServer())
        .post("/api/v1/auth/refresh")
        .send({ refreshToken })
        .expect(200)

      expect(response.body.success).toBe(true)
      expect(response.body.data.accessToken).toBeDefined()
      expect(response.body.data.refreshToken).toBeDefined()

      // Update tokens for next tests
      accessToken = response.body.data.accessToken
      refreshToken = response.body.data.refreshToken
    })

    it("should fail with invalid refresh token", async () => {
      await request(app.getHttpServer())
        .post("/api/v1/auth/refresh")
        .send({ refreshToken: "invalid-token" })
        .expect(401)
    })
  })

  describe("POST /api/v1/auth/logout", () => {
    it("should logout successfully", async () => {
      const response = await request(app.getHttpServer())
        .post("/api/v1/auth/logout")
        .set("Authorization", `Bearer ${accessToken}`)
        .expect(200)

      expect(response.body.success).toBe(true)
    })
  })
})
