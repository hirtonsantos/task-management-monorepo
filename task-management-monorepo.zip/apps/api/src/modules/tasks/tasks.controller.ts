/* eslint-disable */
import { Controller, Get, Post, Patch, Delete, Param, Query, ParseUUIDPipe, HttpCode, HttpStatus } from "@nestjs/common"
import { ApiTags, ApiOperation, ApiBearerAuth, ApiResponse, ApiBody } from "@nestjs/swagger"
import type { TasksService } from "./tasks.service"
import { type CreateTaskDto, type UpdateTaskDto, type TaskQueryDto, BulkUpdateDto, BulkDeleteDto } from "./dto"
import type { User } from "@task-app/database"

@ApiTags("Tasks")
@ApiBearerAuth()
@Controller("tasks")
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  create(dto: CreateTaskDto, user: User) {
    return this.tasksService.create(dto, user)
  }

  @Get()
  @ApiOperation({ summary: "Listar tarefas com filtros" })
  @ApiResponse({ status: 200, description: "Lista paginada de tarefas" })
  findAll(@Query() query: TaskQueryDto, user: User) {
    return this.tasksService.findAll(query, user)
  }

  @Get("stats")
  @ApiOperation({ summary: "Estatísticas das tarefas" })
  @ApiResponse({ status: 200, description: "Estatísticas" })
  getStats(user: User) {
    return this.tasksService.getStats(user)
  }

  @Get(":id")
  @ApiOperation({ summary: "Obter tarefa por ID" })
  @ApiResponse({ status: 200, description: "Dados da tarefa" })
  @ApiResponse({ status: 404, description: "Tarefa não encontrada" })
  findOne(@Param("id", ParseUUIDPipe) id: string, user: User) {
    return this.tasksService.findOne(id, user)
  }

  @Patch(":id")
  @ApiOperation({ summary: "Atualizar tarefa" })
  @ApiResponse({ status: 200, description: "Tarefa atualizada" })
  @ApiResponse({ status: 404, description: "Tarefa não encontrada" })
  update(@Param("id", ParseUUIDPipe) id: string, dto: UpdateTaskDto, user: User) {
    return this.tasksService.update(id, dto, user)
  }

  @Delete(":id")
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: "Remover tarefa (soft delete)" })
  @ApiResponse({ status: 200, description: "Tarefa removida" })
  @ApiResponse({ status: 404, description: "Tarefa não encontrada" })
  remove(@Param("id", ParseUUIDPipe) id: string, user: User) {
    return this.tasksService.remove(id, user)
  }

  @Post(":id/complete")
  @ApiOperation({ summary: "Marcar tarefa como concluída" })
  @ApiResponse({ status: 200, description: "Tarefa concluída" })
  complete(@Param("id", ParseUUIDPipe) id: string, user: User) {
    return this.tasksService.complete(id, user)
  }

  @Patch("bulk/update")
  @ApiOperation({ summary: "Atualizar múltiplas tarefas" })
  @ApiBody({ type: BulkUpdateDto })
  @ApiResponse({ status: 200, description: "Tarefas atualizadas" })
  bulkUpdate(dto: BulkUpdateDto, user: User) {
    const { ids, ...updateData } = dto
    return this.tasksService.bulkUpdate(ids, updateData, user)
  }

  @Delete("bulk/delete")
  @ApiOperation({ summary: "Remover múltiplas tarefas" })
  @ApiBody({ type: BulkDeleteDto })
  @ApiResponse({ status: 200, description: "Tarefas removidas" })
  bulkDelete(dto: BulkDeleteDto, user: User) {
    return this.tasksService.bulkDelete(dto.ids, user)
  }
}
