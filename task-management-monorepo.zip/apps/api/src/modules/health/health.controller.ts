/* eslint-disable */
import { Controller, Get } from "@nestjs/common"
import { ApiTags, ApiOperation } from "@nestjs/swagger"
import { Public } from "../../common/decorators"
import type { HealthService } from "./health.service"

@ApiTags("Health")
@Controller("health")
export class HealthController {
  constructor(private readonly healthService: HealthService) {}

  @Public()
  @Get()
  @ApiOperation({ summary: "Health check básico" })
  check() {
    return this.healthService.check()
  }

  @Public()
  @Get("detailed")
  @ApiOperation({ summary: "Health check detalhado" })
  checkDetailed() {
    return this.healthService.checkDetailed()
  }
}
