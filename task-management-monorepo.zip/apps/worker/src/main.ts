/* eslint-disable */
import { NestFactory } from "@nestjs/core"
import { type MicroserviceOptions, Transport } from "@nestjs/microservices"
import { WorkerModule } from "./worker.module"

async function bootstrap() {
  const app = await NestFactory.createMicroservice<MicroserviceOptions>(WorkerModule, {
    transport: Transport.RMQ,
    options: {
      urls: [process.env.RABBITMQ_URL || "amqp://taskuser:taskpass@localhost:5672"],
      queue: "task_notifications",
      queueOptions: {
        durable: true,
      },
      noAck: false, // Require manual acknowledgment
      prefetchCount: 10, // Process 10 messages at a time
    },
  })

  await app.listen()
  console.log("Worker is listening for messages...")
}

bootstrap()
