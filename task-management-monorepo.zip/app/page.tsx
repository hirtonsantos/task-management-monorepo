"use client"

import  from "../apps/web/src/components/ui/button"

export default function SyntheticV0PageForDeployment() {
  return < />
}